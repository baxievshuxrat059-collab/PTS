// Sahifa yuklanganda
document.addEventListener("DOMContentLoaded", () => {
    console.log("Portal muvaffaqiyatli yuklandi!");
});

// Qidiruv funksiyasi
function searchTopics() {
    let input = document.getElementById("searchInput");
    let filter = input.value.toLowerCase();

    let cards = document.querySelectorAll(".card");

    cards.forEach(card => {
        let text = card.innerText.toLowerCase();

        if(text.includes(filter)){
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}

// Tugmalar uchun animatsiya
const buttons = document.querySelectorAll(".btn");

buttons.forEach(btn => {
    btn.addEventListener("click", () => {
        console.log("Tugma bosildi");
    });
});